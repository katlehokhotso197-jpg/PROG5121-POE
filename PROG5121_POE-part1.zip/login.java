/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

/**
 *
 * @author Katleho Khotso
 */
// Login class handles user authentication
class login {
    private User user;

    // Constructor receives registered user details
    public login(User user) {
        this.user = user;
    }

    // Method to verify username and password
    public boolean authenticate(String username, String password) {

        if (user == null) {
            System.out.println("No user registered yet.");
            return false;
        }

        if (user.username.equals(username) && user.password.equals(password)) {
            System.out.println("Login successful! Welcome, " 
                    + user.firstName + " " + user.lastName);
            return true;
        } else {
            System.out.println("LOGIN UNSUCCESSFUL. Invalid username or password!");
            return false;
        }
    }
}
