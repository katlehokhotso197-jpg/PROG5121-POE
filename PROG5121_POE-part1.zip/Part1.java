/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1;


/**
 *
 * @author Katleho Khotso
 */
import java.util.Scanner;

// User class represents a registered user with their details
class User {
    String firstName;
    String lastName;
    String username;
    String password;
    String cellPhoneNumber;

    User(String firstName, String lastName, String username, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }
}

// Login class handles authentication
class Login {
    private User user;

    Login(User user) {
        this.user = user;
    }

    public boolean authenticate(String username, String password) {
        if (user.username.equals(username) && user.password.equals(password)) {
            System.out.println("Login successful! Welcome, " + user.firstName + " " + user.lastName);
            return true;
        }
        System.out.println("LOGIN UNSUCCESSFUL. Invalid username or password!");
        return false;
    }
}

// Main class
public class Part1 {
    private static User registeredUser;
    private static Scanner input = new Scanner(System.in);
    private static Login loginSystem;

    public static void main(String[] args) {
        while (true) {
            System.out.println("--- Menu ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = input.nextInt();
            input.nextLine(); // consume newline

            if (choice == 1){
                registerUser();
            }
            else if (choice == 2){
                login();
            }
            else if (choice == 3){
                System.out.println("Goodbey");
                break;
            }
            else{
                System.out.println("INVALID CHOISE, PLEASE CHOOSE FROM THE ABOVE OPTION (1, 2, 3)");
            }
        }
    }

    private static void registerUser() {
        System.out.println("--- REGISTERING SYSTEM ---");

        System.out.print("Enter first name here: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name here: ");
        String lastName = input.nextLine();

        String username;
        while (true) {
            System.out.println("Username must contain an underscore and max 5 characters.");
            System.out.println("e.g: las_");
            System.out.print("Enter username: ");
            username = input.nextLine();
            if (username.contains("_") && username.length() <= 5) {
                
                break;
            } else {
                System.out.println("Invalid username. Try again.");
            }
        }

        String password;
        while (true) {
            System.out.println("Password must have at least 8 characters, a number, and a special character.");
            System.out.print("Enter password here: ");
            password = input.nextLine();
            if (isValidPassword(password)) {
                
                break;
            } else {
                System.out.println("Invalid password. Try again.");
            }
        }

        String cellPhoneNumber;
        while (true) {
            System.out.println("Cell phone number must start with +27 and have 9 digits after it.");
            System.out.print("Enter cell phone here: ");
            cellPhoneNumber = input.nextLine();
            if (cellPhoneNumber.startsWith("+27") && cellPhoneNumber.length() == 12 && cellPhoneNumber.substring(3).matches("\\d{9}")) {
                
                break;
            } else {
                System.out.println("Invalid cell phone number. Try again.");
            }
        }

        registeredUser = new User(firstName, lastName, username, password, cellPhoneNumber);
        loginSystem = new Login(registeredUser); // create login system only after registration
        System.out.println("USER SUCCESSFULLY REGISTERED!!!");
    }

    public static void login() {
        System.out.println("--- LOGIN SYSTEM ---");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        loginSystem.authenticate(username, password);
    }

    public static boolean isValidPassword(String password) {
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        return password.length() >= 8 && hasNumber && hasSpecial;
    }
}

